package Com.Example;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

	public class SessionTrackingServlet extends HttpServlet {
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        response.setContentType("text/html");

	        // Check if a session ID exists in the URL
	        String sessionId = request.getParameter("sessionId");

	        // If sessionId exists, show session ID; otherwise, create a new session ID and append it to the URL
	        if (sessionId != null && !sessionId.isEmpty()) {
	            response.getWriter().println("<html><body>");
	            response.getWriter().println("<h1>Your Session ID:</h1>");
	            response.getWriter().println("<p>" + sessionId + "</p>");
	            response.getWriter().println("</body></html>");
	        } else {
	            // Create a new session ID
	            sessionId = "SID" + System.currentTimeMillis();
	            String urlWithSessionId = response.encodeRedirectURL("SessionTrackingServlet?sessionId=" + sessionId);
	            response.sendRedirect(urlWithSessionId);
	        }
	    }
	}
