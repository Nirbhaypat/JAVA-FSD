/**
 * 
 */
/**
 * 
 */
module Example {
	requires java.sql;
}