package com.learning.core.phase1;

import java.util.LinkedHashMap;
import java.util.TreeMap;

public class PracticeprojectAssistedPractice6 {
	
	    public static void main(String[] args) {
	       
	        TreeMap<Integer, String> treeMap = new TreeMap<>();
	        treeMap.put(3, "Three");
	        treeMap.put(1, "One");
	        treeMap.put(2, "Two");

	        System.out.println("TreeMap:");
	        System.out.println("Elements: " + treeMap);
	        System.out.println("Size: " + treeMap.size());
	        System.out.println("Contains key 2: " + treeMap.containsKey(2));
	        System.out.println("Value for key 1: " + treeMap.get(1));
	        System.out.println();

	        LinkedHashMap<String, Integer> linkedHashMap = new LinkedHashMap<>();
	        linkedHashMap.put("Apple", 10);
	        linkedHashMap.put("Banana", 20);
	        linkedHashMap.put("Cherry", 30);

	        System.out.println("LinkedHashMap:");
	        System.out.println("Elements: " + linkedHashMap);
	        System.out.println("Size: " + linkedHashMap.size());
	        System.out.println("Contains key 'Banana': " + linkedHashMap.containsKey("Banana"));
	        System.out.println("Value for key 'Cherry': " + linkedHashMap.get("Cherry"));
	    }
	}

