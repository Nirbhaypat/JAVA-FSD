package com.learning.core.phase1;

public class PracticeprojectAssistedPractice9 {
	
	    public static void main(String[] args) {
	        String str = "Hello, Java!";

	        StringBuffer stringBuffer = new StringBuffer(str);

	        StringBuilder stringBuilder = new StringBuilder(str);

	        System.out.println("Original String: " + str);
	        System.out.println("StringBuffer: " + stringBuffer);
	        System.out.println("StringBuilder: " + stringBuilder);
	    }
	}

