package com.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootStarter2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootStarter2Application.class, args);
	}

}
