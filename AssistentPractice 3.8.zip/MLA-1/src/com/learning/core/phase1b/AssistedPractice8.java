package com.learning.core.phase1b;

import java.util.Stack;

public class AssistedPractice8 {

	    public static void main(String[] args) {
	        Stack<Integer> stack = new Stack<>();

	        System.out.println("Stack after pushing elements:");

	        // Inserting elements into the stack one at a time
	        stack.push(10);
	        stack.push(20);
	        stack.push(30);
	        stack.push(40);
	        System.out.println(stack);
	        
	        stack.push(50);
	        System.out.println("After pushing 50: " + stack);

	        // Removing elements from the stack
	        int removedElement = stack.pop();
	        System.out.println("Removed element: " + removedElement);
	        System.out.println("Stack after popping element:");
	        System.out.println(stack);
	    }
	}