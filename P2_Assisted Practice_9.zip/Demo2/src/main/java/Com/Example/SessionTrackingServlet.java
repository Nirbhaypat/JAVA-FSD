package Com.Example;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionTrackingServlet")
public class SessionTrackingServlet extends HttpServlet {
	
	 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        response.setContentType("text/html");

	        // Get or create a session for the client
	        HttpSession session = request.getSession();

	        // Get the session ID
	        String sessionId = session.getId();

	        // Generate HTML with session ID
	        String htmlResponse = "<html><body>"
	                + "<h1>Session Tracking using HTTP Session</h1>"
	                + "<p>Session ID: " + sessionId + "</p>"
	                + "<a href='SessionTrackingServlet'>Refresh</a>"
	                + "</body></html>";

	        response.getWriter().println(htmlResponse);
	    }
	}