package com.Railway;

@Service
public class CrossingService {
    private final CrossingRepository crossingRepository;

    public CrossingService(CrossingRepository crossingRepository) {
        this.crossingRepository = crossingRepository;
    }

    public Crossing addCrossing(Crossing crossing) {
        // Add logic to add crossing
        return crossingRepository.save(crossing);
    }

    public List<Crossing> getAllCrossings() {
        return crossingRepository.findAll();
    }

    public List<Crossing> searchCrossingsByName(String name) {
        return crossingRepository.findByNameContainingIgnoreCase(name);
    }
}

