package com.learning.core.phase1b;

public class AssistedPractice3 {

	    public static void main(String[] args) {
	        int[] array = {3, 7, 2, 8, 5};
	        int n = array.length;
	        int L = 1; 	        int R = 3; 

	        int sumInRange = sumInRange(array, n, L, R);

	        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sumInRange);
	    }

	    public static int sumInRange(int[] array, int n, int L, int R) {
	        if (L < 0 || R >= n || L > R) {
	            System.out.println("Invalid range.");
	            return 0;
	        }

	        int sum = 0;
	        for (int i = L; i <= R; i++) {
	            sum += array[i];
	        }
	        return sum;
	    }
	}