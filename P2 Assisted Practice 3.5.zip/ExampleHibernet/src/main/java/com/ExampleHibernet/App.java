package com.ExampleHibernet;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class App {
    public static void main(String[] args) {
        Configuration config = new Configuration().configure("hibernet.config.xml")
                .addAnnotatedClass(Employee.class)
                .addAnnotatedClass(Project.class);

        SessionFactory factory = config.buildSessionFactory();
        Session session = factory.getCurrentSession();

        try {
            // Start transaction
            session.beginTransaction();

            // Create sample data
            List<String> skills = new ArrayList<>();
            skills.add("Java");
            skills.add("SQL");

            Set<String> projects = new HashSet<>();
            projects.add("Project A");
            projects.add("Project B");

            Map<String, String> tasks = new HashMap<>();
            tasks.put("Task 1", "Complete by Friday");
            tasks.put("Task 2", "Review code changes");

            // Create and save an employee
            Employee employee = new Employee();
            employee.setName("John Doe");
            employee.setSkills(skills);
            employee.setProjects(projects);
            employee.setTasks(tasks);

            session.save(employee);

            // Commit transaction
            session.getTransaction().commit();
        } catch (Exception e) {
            // Handle exceptions
            e.printStackTrace();
        } finally {
            session.close();
            factory.close();
        }
    }
}
