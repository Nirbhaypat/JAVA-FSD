package Com.Example;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SessionTrackingServlet")
public class SessionTrackingServlet extends HttpServlet {
	
	 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        response.setContentType("text/html");

	        // Create or retrieve session ID
	        String sessionId = (String) request.getSession().getAttribute("sessionId");
	        if (sessionId == null) {
	            sessionId = "SID" + System.currentTimeMillis();
	            request.getSession().setAttribute("sessionId", sessionId);
	        }

	        // Generate HTML with hidden form field
	        String htmlResponse = "<html><body>"
	                + "<h1>Session Tracking using Hidden Form Fields</h1>"
	                + "<form action='SessionTrackingServlet' method='POST'>"
	                + "<input type='hidden' name='sessionId' value='" + sessionId + "'>"
	                + "<input type='submit' value='Track Session'>"
	                + "</form>"
	                + "</body></html>";

	        response.getWriter().println(htmlResponse);
	    }

	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        // Process form submission if needed
	        response.setContentType("text/html");
	        response.getWriter().println("<html><body>");
	        response.getWriter().println("<h1>Form Submitted</h1>");
	        response.getWriter().println("<p>Session ID: " + request.getParameter("sessionId") + "</p>");
	        response.getWriter().println("</body></html>");
	    }
	
}
    