package com.learning.core.phase1a;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class PracticeProject1 {

	    public static void main(String[] args) {
	        // Specify the file path
	        String filePath = "C:\\Users\\l_nirbhay_l\\Desktop\\example.txt";

	        // Write to file
	        writeToFile(filePath, "This is a sample text.");

	        // Read from file
	        String content = readFromFile(filePath);
	        System.out.println("File content:");
	        System.out.println(content);

	        // Append to file
	        appendToFile(filePath, "\nThis is an appended text.");
	    }

	    // Method to write to a file
	    public static void writeToFile(String filePath, String content) {
	        try (FileWriter writer = new FileWriter(filePath)) {
	            writer.write(content);
	            System.out.println("Content written to file.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while writing to the file.");
	            e.printStackTrace();
	        }
	    }

	    // Method to read from a file
	    public static String readFromFile(String filePath) {
	        StringBuilder content = new StringBuilder();
	        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                content.append(line).append("\n");
	            }
	        } catch (IOException e) {
	            System.out.println("An error occurred while reading from the file.");
	            e.printStackTrace();
	        }
	        return content.toString();
	    }

	    // Method to append to a file
	    public static void appendToFile(String filePath, String content) {
	        try (FileWriter writer = new FileWriter(filePath, true)) {
	            writer.write(content);
	            System.out.println("Content appended to file.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while appending to the file.");
	            e.printStackTrace();
	        }
	    }
	}


