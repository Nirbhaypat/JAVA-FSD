package com.learning.core.phase1;

public class PracticeprojectAssistedPractice1 {
	
	
	    public static void main(String[] args) {
	        
	        int numInt = 10;
	        double numDouble = numInt; 
	        System.out.println("Implicit Casting:");
	        System.out.println("Integer value: " + numInt);
	        System.out.println("Double value after implicit casting: " + numDouble);

	     
	        double doubleNum = 15.75;
	        int intNum = (int) doubleNum; 

	        System.out.println("\nExplicit Casting:");
	        System.out.println("Double value: " + doubleNum);
	        System.out.println("Integer value after explicit casting: " + intNum);

	    
	        double largeDouble = 123456789.123;
	        int truncatedInt = (int) largeDouble; 

	        System.out.println("\nExplicit Casting with Potential Data Loss:");
	        System.out.println("Double value: " + largeDouble);
	        System.out.println("Integer value after explicit casting with data loss: " + truncatedInt);
	    }
	}



