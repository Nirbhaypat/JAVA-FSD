package com.learning.core.phase1b;

		
	class Node {
	    int data;
	    Node next;

	    Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

public class AssistedPractice6 {
	
	    Node head;

	    public AssistedPractice6() {
	        this.head = null;
	    }

	    public void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) { // If list is empty
	            head = newNode;
	            head.next = head; // Point to itself in a circular manner
	        } else if (data <= head.data) { // If data is less than or equal to head's data
	            newNode.next = head;
	            Node last = getLastNode();
	            last.next = newNode;
	            head = newNode;
	        } else {
	            Node current = head;
	            while (current.next != head && current.next.data < data) {
	                current = current.next;
	            }
	            newNode.next = current.next;
	            current.next = newNode;
	        }
	        display();
	    }

	    public Node getLastNode() {
	        Node last = head;
	        while (last.next != head) {
	            last = last.next;
	        }
	        return last;
	    }

	    public void display() {
	        if (head == null) {
	            System.out.println("List is empty.");
	            return;
	        }
	        Node current = head;
	        do {
	            System.out.print(current.data + " -> ");
	            current = current.next;
	        } while (current != head);
	        System.out.println(" (head)");
	    }

	    public static void main(String[] args) {
	    	AssistedPractice6 list = new AssistedPractice6();
	        list.insert(5);
	        list.insert(10);
	        list.insert(2);
	        list.insert(7);
	    }
	}

	

