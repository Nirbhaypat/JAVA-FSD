package com.ExampleHibernet;

	import javax.persistence.*;

	@Entity
	@Table(name = "projects")
	public class Project {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "id")
	    private Long id;

	    @Column(name = "project_name")
	    private String projectName;

	    @ManyToOne
	    @JoinColumn(name = "employee_id")
	    private Employee employee;

	    // Constructors
	    public Project() {
	    }

	    public Project(String projectName, Employee employee) {
	        this.projectName = projectName;
	        this.employee = employee;
	    }

	    // Getters and setters
	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public String getProjectName() {
	        return projectName;
	    }

	    public void setProjectName(String projectName) {
	        this.projectName = projectName;
	    }

	    public Employee getEmployee() {
	        return employee;
	    }

	    public void setEmployee(Employee employee) {
	        this.employee = employee;
	    }
	}

