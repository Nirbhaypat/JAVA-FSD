package com.learning.core.phase1a;

public class AssistedPractice2 {

	    public static void main(String[] args) {
	        final Object lock = new Object(); 

	        
	        Thread sleepThread = new Thread(() -> {
	            System.out.println("SleepThread: Going to sleep for 3 seconds.");
	            try {
	                Thread.sleep(3000); 
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	            System.out.println("SleepThread: Woke up after sleeping.");
	        });

	      
	        Thread waitThread = new Thread(() -> {
	            synchronized (lock) {
	                System.out.println("WaitThread: Acquired lock, waiting for notification.");
	                try {
	                    lock.wait();
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	                System.out.println("WaitThread: Got notified, continuing execution.");
	            }
	        });

	        sleepThread.start();
	        waitThread.start();

	        try {
	            Thread.sleep(1000); 
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        synchronized (lock) {
	            System.out.println("Main Thread: Sending notification to waitThread.");
	            lock.notify(); 
	        }
	    }
	}