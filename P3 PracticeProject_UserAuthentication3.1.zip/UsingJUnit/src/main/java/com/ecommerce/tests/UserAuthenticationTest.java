package com.ecommerce.tests;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

public class UserAuthenticationTest {
    @Test
    public void testValidCredentials() {
        UserAuthentication auth = new UserAuthentication();
        assertTrue(auth.authenticate("admin", "password"));
    }

    @Test
    public void testInvalidCredentials() {
        UserAuthentication auth = new UserAuthentication();
        assertFalse(auth.authenticate("user", "wrongpassword"));
    }
}
