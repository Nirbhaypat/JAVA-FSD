package com.ExampleHibernet;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {
	@Id
	private int roll;
	private int phnno;
	private String name;
	private String address;
	private String Gender;
	public Student() {
		
	}
	public Student(int roll,int phnno, String name, String address , String Gender) {
		this.Gender=Gender;
		this.phnno = phnno;
		this.roll = roll;
		this.name = name;
		this.address = address;
	}
	
	public int getroll() {
		return roll;
	}
	public void setroll(int roll) {
		this.roll = roll;
	}
	
	
	public int getphnno() {
		return phnno;
	}
	public void setphnno(int troll) {
		this.phnno = phnno;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return Gender;
	}
	public void setEmail(String email) {
		this.Gender = Gender;
	}
}
