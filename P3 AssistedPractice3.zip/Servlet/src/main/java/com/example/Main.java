package com.example;

import org.springframework.beans.factory.annotation.Autowired;

@SpringBootApplication
public class Main {
	@Autowired
	private EmployeeDAO employeeDAO;

	public static void main(String[] args) {
		SpringApplication.run(Main.class, args);
	}

	@PostConstruct
	public void init() {
		Employee employee1 = new Employee(1, "John Doe", "Software Engineer");
		Employee employee2 = new Employee(2, "Jane Doe", "Project Manager");
		employeeDAO.save(employee1);
		employeeDAO.save(employee2);
		System.out.println("Employees saved: " + employeeDAO.getAll());
		employee1.setName("John Smith");
		employee1.setRole("Senior Software Engineer");
		employeeDAO.update(employee1);
		System.out.println("Employees updated: " + employeeDAO.getAll());
		employeeDAO.deleteById(2);
		System.out.println("Employees deleted: " + employeeDAO.getAll());
	}
}
