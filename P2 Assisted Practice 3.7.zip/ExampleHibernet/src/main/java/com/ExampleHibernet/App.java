package com.ExampleHibernet;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class App {
    public static void main(String[] args) {
        Configuration config = new Configuration().configure("hibernet.config.xml")
                .addAnnotatedClass(Employee.class);

        SessionFactory factory = config.buildSessionFactory();
        Session session = factory.getCurrentSession();

        try {
            // Start transaction
            session.beginTransaction();

            // Create an employee with an address
            Address address = new Address();
            address.setStreet("123 Main St");
            address.setCity("Anytown");
            address.setZipCode("12345");

            Employee employee = new Employee();
            employee.setAddress(address);

            session.save(employee);

            // Commit transaction
            session.getTransaction().commit();
        } catch (Exception e) {
            // Handle exceptions
        } finally {
            session.close();
            factory.close();
        }
    }
}
