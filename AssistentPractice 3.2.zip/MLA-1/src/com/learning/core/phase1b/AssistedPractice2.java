package com.learning.core.phase1b;

import java.util.PriorityQueue;

public class AssistedPractice2 {

	    public static void main(String[] args) {
	        int[] array = {10, 7, 3, 9, 2, 5, 8, 1, 6, 4};
	        int k = 4; // Fourth smallest element

	        int fourthSmallest = findFourthSmallest(array, k);

	        System.out.println("Fourth Smallest Element: " + fourthSmallest);
	    }

	    public static int findFourthSmallest(int[] array, int k) {
	        PriorityQueue<Integer> minHeap = new PriorityQueue<>();

	        // Add all elements to the min heap
	        for (int num : array) {
	            minHeap.offer(num);
	        }

	        // Remove k-1 smallest elements
	        for (int i = 0; i < k - 1; i++) {
	            minHeap.poll();
	        }

	        // The kth element in the heap is the kth smallest
	        return minHeap.peek();
	    }
	}
