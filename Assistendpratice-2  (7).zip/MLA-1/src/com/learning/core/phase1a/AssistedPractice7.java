package com.learning.core.phase1a;
	import java.io.File;
	import java.io.FileWriter;
	import java.io.FileReader;
	import java.io.IOException;
	import java.util.Scanner;

	public class AssistedPractice7 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        createFile();
	        readFile();

	        System.out.println("Enter text to append to the file:");
	        String newText = scanner.nextLine();
	        updateFile(newText);
	        readFile();
	        deleteFile();

	        scanner.close();
	    }

	    public static void createFile() {
	        try {
	            File file = new File("sample.txt");
	            if (file.createNewFile()) {
	                System.out.println("File created: " + file.getName());
	            } else {
	                System.out.println("File already exists.");
	            }
	        } catch (IOException e) {
	            System.out.println("An error occurred while creating the file.");
	            e.printStackTrace();
	        }
	    }

	    public static void readFile() {
	        try (FileReader reader = new FileReader("sample.txt")) {
	            System.out.println("File content:");
	            int character;
	            while ((character = reader.read()) != -1) {
	                System.out.print((char) character);
	            }
	            System.out.println(); // Add a new line after reading content
	        } catch (IOException e) {
	            System.out.println("An error occurred while reading the file.");
	            e.printStackTrace();
	        }
	    }

	    public static void updateFile(String newText) {
	        try (FileWriter writer = new FileWriter("sample.txt", true)) {
	            writer.write(newText);
	            System.out.println("Text appended to the file.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while updating the file.");
	            e.printStackTrace();
	        }
	    }

	    public static void deleteFile() {
	        File file = new File("sample.txt");
	        if (file.delete()) {
	            System.out.println("File deleted successfully.");
	        } else {
	            System.out.println("Failed to delete the file.");
	        }
	    }
	}

