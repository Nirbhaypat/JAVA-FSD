package com.abc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo {
   
	 private static final String DB_URL = "jdbc:mysql://localhost:3306/demo_db";
	    private static final String DB_USER = "root";
	    private static final String DB_PASSWORD = "9355";
	    private static final String DB_NAME = "demo_db";

	    public static void main(String[] args) {
	        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
	            System.out.println("Connected to the database.");

	            // Insertion Example
	            insertRecord(connection, 101, "John Doe", "john.doe@example.com");

	            // Updation Example
	            updateRecord(connection, 101, "John Doe Updated", "john.doe.updated@example.com");

	            // Deletion Example
	            deleteRecord(connection, 101);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    private static void insertRecord(Connection connection, int id, String name, String email) throws SQLException {
	        String insertSQL = "INSERT INTO employee (id, Name, Email) VALUES (?, ?, ?)";
	        try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {
	            preparedStatement.setInt(1, id);
	            preparedStatement.setString(2, name);
	            preparedStatement.setString(3, email);
	            int rowsInserted = preparedStatement.executeUpdate();
	            System.out.println(rowsInserted + " row(s) inserted.");
	        }
	    }

	    private static void updateRecord(Connection connection, int id, String newName, String newEmail) throws SQLException {
	        String updateSQL = "UPDATE employee SET Name = ?, Email = ? WHERE id = ?";
	        try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {
	            preparedStatement.setString(1, newName);
	            preparedStatement.setString(2, newEmail);
	            preparedStatement.setInt(3, id);
	            int rowsUpdated = preparedStatement.executeUpdate();
	            System.out.println(rowsUpdated + " row(s) updated.");
	        }
	    }

	    private static void deleteRecord(Connection connection, int id) throws SQLException {
	        String deleteSQL = "DELETE FROM employee WHERE id = ?";
	        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL)) {
	            preparedStatement.setInt(1, id);
	            int rowsDeleted = preparedStatement.executeUpdate();
	            System.out.println(rowsDeleted + " row(s) deleted.");
	        }
	    }
	}