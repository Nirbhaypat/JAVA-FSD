package com.learning.core.phase1b;

	class Node {
	    int data;
	    Node next;

	    Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

	public class AssistedPractice5 {
	    Node head;

	    public AssistedPractice5() {
	        this.head = null;
	    }

	    public void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	        } else {
	            newNode.next = head;
	            head = newNode;
	        }
	    }

	    public void delete(int key) {
	        Node prev = null;
	        Node current = head;

	        // Traverse the list to find the key
	        while (current != null && current.data != key) {
	            prev = current;
	            current = current.next;
	        }

	        // If key is found, delete the node
	        if (current != null) {
	            if (prev == null) { // If key is in the first node
	                head = current.next;
	            } else {
	                prev.next = current.next;
	            }
	            System.out.println("Key " + key + " deleted successfully.");
	        } else {
	            System.out.println("Key " + key + " not found.");
	        }
	    }

	    public void display() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " -> ");
	            current = current.next;
	        }
	        System.out.println("null");
	    }

	    public static void main(String[] args) {
	        AssistedPractice5 list = new AssistedPractice5();
	        list.insert(5);
	        list.insert(3);
	        list.insert(8);
	        list.insert(2);

	        System.out.println("Original List:");
	        list.display();

	        int keyToDelete = 8;
	        list.delete(keyToDelete);

	        System.out.println("List after deleting key " + keyToDelete + ":");
	        list.display();
	    }
	}