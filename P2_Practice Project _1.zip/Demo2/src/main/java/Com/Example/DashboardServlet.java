package Com.Example;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class DashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("username") != null) {
            // User is logged in
            response.setContentType("text/html");
            response.getWriter().println("<html><body>");
            response.getWriter().println("<h1>Welcome to the Dashboard</h1>");
            response.getWriter().println("<p>You are logged in as: " + session.getAttribute("username") + "</p>");
            response.getWriter().println("<a href='logout'>Logout</a>");
            response.getWriter().println("</body></html>");
        } else {
            // Redirect to login page if not logged in
            response.sendRedirect("login.html");
        }
    }
}
