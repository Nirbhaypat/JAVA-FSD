package com.learning.core.phase1;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class PracticeprojectAssistedPractice7 {

	    public static void main(String[] args) {
	       
	        Map<String, Integer> hashMap = new HashMap<>();
	        hashMap.put("Alice", 25);
	        hashMap.put("Bob", 30);
	        hashMap.put("Charlie", 20);

	        System.out.println("HashMap:");
	        System.out.println("Elements: " + hashMap);
	        System.out.println("Size: " + hashMap.size());
	        System.out.println("Contains key 'Bob': " + hashMap.containsKey("Bob"));
	        System.out.println("Value for key 'Alice': " + hashMap.get("Alice"));
	        System.out.println();

	        Map<String, Integer> treeMap = new TreeMap<>();
	        treeMap.put("Apple", 10);
	        treeMap.put("Banana", 20);
	        treeMap.put("Cherry", 15);

	        System.out.println("TreeMap:");
	        System.out.println("Elements: " + treeMap);
	        System.out.println("Size: " + treeMap.size());
	        System.out.println("Contains key 'Banana': " + treeMap.containsKey("Banana"));
	        System.out.println("Value for key 'Cherry': " + treeMap.get("Cherry"));
	    }
	}


