package com.ExampleHibernet;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("ApplicationContext.xml");
        ProductService productService = context.getBean(ProductService.class);

        // Create a new product and add it to the database
        Product product = new Product();
        product.setName("New Product");
        product.setPrice(99.99);

        productService.addProduct(product);

        System.out.println("Product added successfully.");
    }
}
