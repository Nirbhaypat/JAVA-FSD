package com.abc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo {
   
	private static final String DB_URL = "jdbc:mysql://localhost:3306/demo_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "9355";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            System.out.println("Connected to the database.");

            // Create a statement for executing SQL queries
            try (Statement statement = connection.createStatement()) {
                // Example SELECT query
                String sqlQuery = "SELECT id, Name, Email FROM employee";
                ResultSet resultSet = statement.executeQuery(sqlQuery);

                // Process the query result
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String name = resultSet.getString("Name");
                    String email = resultSet.getString("Email");
                    System.out.println("ID: " + id + ", Name: " + name + ", Email: " + email);
                }
            } catch (SQLException e) {
                System.err.println("Error executing SQL query: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Database connection error: " + e.getMessage());
        }
    }
}