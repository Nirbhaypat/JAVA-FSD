package com.ExampleHibernet;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
    @Autowired
    private ProductDAO productDAO;

    @Transactional
    public void addProduct(Product product) {
        productDAO.saveProduct(product);
    }
}
