package com.learning.core.phase1b;

public class AssistedPractice7 {

	    private Node head;

	    private static class Node {
	        private int data;
	        private Node next;
	        private Node prev;

	        public Node(int data) {
	            this.data = data;
	            this.next = null;
	            this.prev = null;
	        }
	    }

	    public AssistedPractice7(int[] data) {
	        if (data == null || data.length == 0) {
	            head = null;
	            return;
	        }

	        head = new Node(data[0]);
	        Node curr = head;
	        for (int i = 1; i < data.length; i++) {
	            curr.next = new Node(data[i]);
	            curr.next.prev = curr;
	            curr = curr.next;
	        }
	    }

	    // Traverse the list in the forward direction
	    public void traverseForward() {
	        Node curr = head;
	        System.out.print("Forward direction: ");
	        while (curr != null) {
	            System.out.print(curr.data + " ");
	            curr = curr.next;
	        }
	        System.out.println();
	    }

	    // Traverse the list in the backward direction
	    public void traverseBackward() {
	        Node curr = head;
	        if (curr == null) {
	            return;
	        }
	        while (curr.next != null) {
	            curr = curr.next;
	        }
	        System.out.print("Backward direction: ");
	        while (curr != null) {
	            System.out.print(curr.data + " ");
	            curr = curr.prev;
	        }
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        int[] data = {1, 2, 3, 4, 5};
	        AssistedPractice7 list = new AssistedPractice7(data);
	        list.traverseForward();
	        list.traverseBackward();
	    }
	}

