package Com.Example;

import javax.servlet.Servlet;

public interface MyInterface extends Servlet {
    void myMethod();
}
