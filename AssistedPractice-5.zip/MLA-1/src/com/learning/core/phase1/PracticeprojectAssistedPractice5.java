package com.learning.core.phase1;

import java.util.ArrayList;
import java.util.HashMap;

public class PracticeprojectAssistedPractice5 {

	    public static void main(String[] args) {
	        
	        ArrayList<String> arrayList = new ArrayList<>();
	        arrayList.add("Apple");
	        arrayList.add("Banana");
	        arrayList.add("Cherry");

	        System.out.println("ArrayList:");
	        System.out.println("Elements: " + arrayList);
	        System.out.println("Size: " + arrayList.size());
	        System.out.println("Contains 'Banana': " + arrayList.contains("Banana"));
	        System.out.println();

	      
	        HashMap<Integer, String> hashMap = new HashMap<>();
	        hashMap.put(1, "One");
	        hashMap.put(2, "Two");
	        hashMap.put(3, "Three");

	        System.out.println("HashMap:");
	        System.out.println("Elements: " + hashMap);
	        System.out.println("Size: " + hashMap.size());
	        System.out.println("Contains key 2: " + hashMap.containsKey(2));
	        System.out.println("Value for key 3: " + hashMap.get(3));
	    }
	}
