package com.learning.core.Project;

	import java.util.HashMap;
	import java.util.Map;
	import java.util.Scanner;

	public class FrontDesk {
	    private String username;
	    private String password;
	    private Map<String, Double> seatPrices;
	    private Map<String, Boolean> seatAvailability; // Map<SeatNumber, Availability>
	    private Map<String, Boolean> bookingStatus; // Map<BookingID, Status>
	    private int bookingIdCounter;

	    public FrontDesk(String username, String password) {
	        this.username = username;
	        this.password = password;
	        this.seatPrices = new HashMap<>();
	        this.seatAvailability = new HashMap<>();
	        this.bookingStatus = new HashMap<>();
	        this.bookingIdCounter = 1000; // Start booking IDs from 1000
	        initializeSeatPrices();
	        initializeSeatAvailability();
	    }

	    private void initializeSeatPrices() {
	        // Initialize seat prices
	        seatPrices.put("A1", 100.0);
	        seatPrices.put("A2", 100.0);
	        seatPrices.put("B1", 80.0);
	        seatPrices.put("B2", 80.0);
	        // Add more seats and prices as needed
	    }

	    private void initializeSeatAvailability() {
	        // Initialize seat availability (all seats initially available)
	        for (String seat : seatPrices.keySet()) {
	            seatAvailability.put(seat, true);
	        }
	    }

	    public boolean login(String enteredUsername, String enteredPassword) {
	        return username.equals(enteredUsername) && password.equals(enteredPassword);
	    }

	    public void updatePassword(String newPassword) {
	        this.password = newPassword;
	        System.out.println("Password updated successfully.");
	    }
	    
	    public void viewSeatingArrangement(String date, String showTime) {
	        // Implement logic to display seating arrangement for the given date and show time
	        System.out.println("Seating Arrangement for " + date + " " + showTime + ":");
	        char rowLabel = 'A';
	        for (int row = 1; row <= 5; row++) {
	            for (int seatNum = 1; seatNum <= 5; seatNum++) {
	                String seat = rowLabel + "" + seatNum;
	                if (seatAvailability.containsKey(seat) && seatAvailability.get(seat)) {
	                    System.out.print(seat + "(Available) ");
	                } else {
	                    System.out.print(seat + "(Booked) ");
	                }
	            }
	            rowLabel++; // Move to the next row label
	            System.out.println(); // Move to the next line after displaying seats in a row
	        }
	    }

	    public void bookTicket(String date, String showTime, String seatSelection) {
	        // Implement logic to book the ticket
	        double totalPrice = calculateTotalPrice(seatSelection);
	        System.out.println("Total amount to be paid: $" + totalPrice);

	        // Ask for payment and confirm booking
	        boolean paymentSuccessful = processPayment(totalPrice);
	        if (paymentSuccessful) {
	            confirmBooking(date, showTime, seatSelection);
	        } else {
	            System.out.println("Payment failed. Booking not confirmed.");
	        }
	    }

	    private double calculateTotalPrice(String seatSelection) {
	        double totalPrice = 0.0;
	        String[] selectedSeats = seatSelection.split(",");
	        for (String seat : selectedSeats) {
	            if (seatPrices.containsKey(seat)) {
	                totalPrice += seatPrices.get(seat);
	            }
	        }
	        return totalPrice;
	    }

	    private boolean processPayment(double totalPrice) {
	        // Implement payment logic (placeholder for demonstration)
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter payment amount: $");
	        double paymentAmount = scanner.nextDouble();
	        scanner.nextLine(); // Consume newline character
	        scanner.close();

	        return paymentAmount >= totalPrice; // Payment successful if amount is sufficient
	    }

	    private void confirmBooking(String date, String showTime, String seatSelection) {
	        // Update seat availability and booking status
	        String bookingId = "B" + bookingIdCounter++;
	        bookingStatus.put(bookingId, true);

	        String[] selectedSeats = seatSelection.split(",");
	        for (String seat : selectedSeats) {
	            seatAvailability.put(seat, false); // Mark seat as unavailable
	        }

	        System.out.println("Booking ID: " + bookingId);
	    }

	    public void checkBookingStatus(String bookingId) {
	    	
	        if (bookingStatus.containsKey(bookingId)) {
	            boolean status = bookingStatus.get(bookingId);
	            System.out.println("Booking ID: " + bookingId + ", Status: " + (status ? "Confirmed" : "Cancelled"));
	        } else {
	            System.out.println("Booking ID not found.");
	        }
	    }

	    public static void main(String[] args) {
	        FrontDesk frontDesk = new FrontDesk("admin", "password");

	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter username: ");
	        String usernameInput = scanner.nextLine();

	        System.out.print("Enter password: ");
	        String passwordInput = scanner.nextLine();

	        if (frontDesk.login(usernameInput, passwordInput)) {
	            System.out.println("Login successful!");

	            System.out.print("Enter date (YYYY-MM-DD): ");
	            String date = scanner.nextLine();

	            System.out.print("Enter show time: ");
	            String showTime = scanner.nextLine();

	            frontDesk.viewSeatingArrangement(date, showTime);

	            System.out.print("Enter seat selection (e.g., A1,B2,C3): ");
	            String seatSelection = scanner.nextLine();

	            frontDesk.bookTicket(date, showTime, seatSelection);

	            System.out.print("Booking status: Booking Confirmed ");
	            System.out.println("");
	            System.out.println("");
	            String bookingId = scanner.nextLine();
	            
	            frontDesk.checkBookingStatus(bookingId);
	        } else {
	            System.out.println("Invalid username or password.");
	            System.out.print("Do you want to update your password? (yes/no): ");
	            String choice = scanner.nextLine();
	            if (choice.equalsIgnoreCase("yes")) {
	                System.out.print("Enter new password: ");
	                String newPassword = scanner.nextLine();
	                frontDesk.updatePassword(newPassword);

	                // Proceed with login after updating password
	                System.out.print("Enter date (YYYY-MM-DD): ");
	                String date = scanner.nextLine();

	                System.out.print("Enter show time: ");
	                String showTime = scanner.nextLine();

	                frontDesk.viewSeatingArrangement(date, showTime);

	                System.out.print("Enter seat selection (e.g., A1,B2,C3): ");
	                String seatSelection = scanner.nextLine();

	                frontDesk.bookTicket(date, showTime, seatSelection);

	               System.out.print("Booking status: Booking Confirmed ");
	               System.out.println("");
	               System.out.println("");
	                String bookingId = scanner.nextLine();
	                frontDesk.checkBookingStatus(bookingId);
	            } else {
	                System.out.println("Goodbye!");
	            }
	        }

	        scanner.close();
	    }
	}
	
