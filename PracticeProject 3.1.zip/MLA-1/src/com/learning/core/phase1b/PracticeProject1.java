package com.learning.core.phase1b;

import java.util.Arrays;

public class PracticeProject1 {

	    public static int findLongestIncreasingSubsequence(int[] nums) {
	        if (nums == null || nums.length == 0) {
	            return 0;
	        }

	        int n = nums.length;
	        int[] dp = new int[n];
	        Arrays.fill(dp, 1);

	        int maxLength = 1;

	        for (int i = 1; i < n; i++) {
	            for (int j = 0; j < i; j++) {
	                if (nums[i] > nums[j]) {
	                    dp[i] = Math.max(dp[i], dp[j] + 1);
	                    maxLength = Math.max(maxLength, dp[i]);
	                }
	            }
	        }

	        return maxLength;
	    }

	    public static void main(String[] args) {
	        int[] nums = {10, 22, 9, 33, 21, 50, 41, 60, 80};
	        int longestLength = findLongestIncreasingSubsequence(nums);
	        System.out.println("Length of longest increasing subsequence: " + longestLength);
	    }
	}