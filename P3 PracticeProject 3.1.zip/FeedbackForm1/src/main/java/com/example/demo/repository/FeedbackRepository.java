package com.example.demo.repository;

import com.example.demo.entity.Feedback;
import org.springframework.data.repository.CrudRepository;

public interface FeedbackRepository extends CrudRepository;