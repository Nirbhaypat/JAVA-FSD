package com.learning.core.phase1;

public class PracticeprojectAssistedPractice10 {
//	public class ArrayVerification {
	    public static void main(String[] args) {
	        // Creating and initializing an array of integers
	        int[] intArray = {10, 20, 30, 40, 50};

	        // Displaying the elements of the intArray
	        System.out.println("Elements of intArray:");
	        for (int i = 0; i < intArray.length; i++) {
	            System.out.println(intArray[i]);
	        }

	        // Accessing and modifying elements of the intArray
	        intArray[2] = 35;
	        System.out.println("\nModified element at index 2: " + intArray[2]);

	        // Creating and initializing an array of strings
	        String[] strArray = {"Apple", "Banana", "Cherry"};

	        // Displaying the elements of the strArray
	        System.out.println("\nElements of strArray:");
	        for (int i = 0; i < strArray.length; i++) {
	            System.out.println(strArray[i]);
	        }

	        // Accessing and modifying elements of the strArray
	        strArray[1] = "Grapes";
	        System.out.println("\nModified element at index 1: " + strArray[1]);
	    }
	}
	

