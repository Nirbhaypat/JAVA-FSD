package com.learning.core.phase1;

public class PracticeprojectAssistedPractice4 {
	    private int value;

	    public PracticeprojectAssistedPractice4() {
	        System.out.println("Default Constructor called");
	        this.value = 0;
	    }
	    public PracticeprojectAssistedPractice4(int value) {
	        System.out.println("Parameterized Constructor with one parameter called");
	        this.value = value;
	    }

	    public PracticeprojectAssistedPractice4(int value1, int value2) {
	        System.out.println("Parameterized Constructor with two parameters called");
	        this.value = value1 + value2;
	    }

	    public PracticeprojectAssistedPractice4(PracticeprojectAssistedPractice4 other) {
	        System.out.println("Copy Constructor called");
	        this.value = other.value;
	    }

	    public int getValue() {
	        return value;
	    }

	    public static void main(String[] args) {

	    	PracticeprojectAssistedPractice4 defaultObj = new PracticeprojectAssistedPractice4();
	    	PracticeprojectAssistedPractice4 paramObj1 = new PracticeprojectAssistedPractice4(10);
	    	PracticeprojectAssistedPractice4 paramObj2 = new PracticeprojectAssistedPractice4(20, 30);
	    	PracticeprojectAssistedPractice4 copyObj = new PracticeprojectAssistedPractice4(paramObj2);

	        System.out.println("Default Object Value: " + defaultObj.getValue());
	        System.out.println("Parameterized Object 1 Value: " + paramObj1.getValue());
	        System.out.println("Parameterized Object 2 Value: " + paramObj2.getValue());
	        System.out.println("Copy Object Value: " + copyObj.getValue());
	    }
	}


