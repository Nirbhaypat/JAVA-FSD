package com.learning.core.phase1a;

class MyCustomException extends Exception {
 public MyCustomException(String message) {
     super(message);
 }
}

public class AssistedPractice5 {
 public static void methodWithThrows(int num) throws MyCustomException { //throws block
     if (num == 0) {
         throw new MyCustomException("Cannot divide by zero");
     }
     System.out.println("Result of division: " + (10 / num));
 }

 public static void methodWithThrow(int num) {
	 //throw block
     if (num == 0) {
         throw new IllegalArgumentException("Argument cannot be zero");
     }
     System.out.println("Result of division: " + (10 / num));
 }

 public static void main(String[] args) {
	 //try catch finaly block
    try {
         methodWithThrow(0);
     } catch (IllegalArgumentException e) {
         System.out.println("Caught IllegalArgumentException: " + e.getMessage());
     } finally {
         System.out.println("Inside finally block");
     }
 }
}

