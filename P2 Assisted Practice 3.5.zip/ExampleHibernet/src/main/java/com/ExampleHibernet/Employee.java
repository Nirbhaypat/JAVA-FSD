package com.ExampleHibernet;
import java.util.List;
import java.util.Set;
import java.util.Map;

public class Employee {
    private int id;
    private String name;
    private List<String> skills;
    private Set<String> projects;
    private Map<String, String> tasks;

    public Employee() {
        // Default constructor
    }

    public Employee(int id, String name, List<String> skills, Set<String> projects, Map<String, String> tasks) {
        this.id = id;
        this.name = name;
        this.skills = skills;
        this.projects = projects;
        this.tasks = tasks;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getSkills() {
        return skills;
    }

    public void setSkills(List<String> skills) {
        this.skills = skills;
    }

    public Set<String> getProjects() {
        return projects;
    }

    public void setProjects(Set<String> projects) {
        this.projects = projects;
    }

    public Map<String, String> getTasks() {
        return tasks;
    }

    public void setTasks(Map<String, String> tasks) {
        this.tasks = tasks;
    }
}
