package com.learning.core.phase1a;

	interface A {
	    default void displayA() {
	        System.out.println("A");
	    }
	}
	interface B extends A {
	    default void displayB() {
	        System.out.println("B");
	    }
	}
	interface C extends A {
	    default void displayC() {
	        System.out.println("C");
	    }
	}
	interface D extends B, C {
	    @Override
	    default void displayA() {
	        B.super.displayA(); // Call displayA()
	    }
	    
	    @Override
	    default void displayB() {
	        B.super.displayB(); // Call displayB()
	    }

	    @Override
	    default void displayC() {
	        C.super.displayC(); 
	    }
	}

	public class AssistedPractice9 implements D {
	    public static void main(String[] args) {
	        AssistedPractice9 obj = new AssistedPractice9();
	        obj.displayA(); // Output: A
	        obj.displayB(); // Output: B
	        obj.displayC(); // Output: C
	    }
	}