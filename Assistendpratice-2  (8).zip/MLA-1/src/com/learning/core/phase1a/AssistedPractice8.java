package com.learning.core.phase1a;
	
		class Animal {
	    private String name;

	    // Constructor
	    public Animal(String name) {
	        this.name = name;
	    }

	    // Encapsulation
	    public String getName() {
	        return name;
	    }

	    // Abstraction
	    public void makeSound() {
	    }
	}

	// Child class inheriting from Animal
	class Dog extends Animal {
	    // Constructor calling super constructor
	    public Dog(String name) {
	        super(name);
	    }

	    // Polymorphism
	    @Override
	    public void makeSound() {
	        System.out.println(getName() + " says Woof!");
	    }
	}

	// Child class inheriting from Animal
	class Cat extends Animal {
	    // Constructor calling super constructor
	    public Cat(String name) {
	        super(name);
	    }

	    // Polymorphism
	    @Override
	    public void makeSound() {
	        System.out.println(getName() + " says Meow!");
	    }
	}

	public class AssistedPractice8 {
	    public static void main(String[] args) {
	        Dog dog = new Dog("Buddy");
	        Cat cat = new Cat("Whiskers");

	        dog.makeSound(); // Polymorphism
	        cat.makeSound(); // Polymorphism
	    }
	}



