package com.example.demo;

public interface ProductRepository extends JpaRepository<ProductEntity, Integer>{

}

