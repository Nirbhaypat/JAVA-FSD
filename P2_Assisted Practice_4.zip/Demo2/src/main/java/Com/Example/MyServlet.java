package Com.Example;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;

import java.io.IOException;

@WebServlet("/MyServlet")

public class MyServlet implements MyInterface {
    private ServletConfig config;

    @Override
    public void init(ServletConfig config) throws ServletException {
        this.config = config;
    }

    @Override
    public ServletConfig getServletConfig() {
        return this.config;
    }

    @Override
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        res.getWriter().println("<html><body>");
        res.getWriter().println("<h1>Hello from MyServlet implementing MyInterface!</h1>");
        res.getWriter().println("</body></html>");
    }

    @Override
    public String getServletInfo() {
        return "MyServlet implementing MyInterface";
    }

    @Override
    public void destroy() {
        // Clean-up code if needed
    }

    @Override
    public void myMethod() {
        System.out.println("Executing myMethod() in MyServlet");
    }
}

