package com.learning.core.phaseC;

public class AssistedPractrice1 {

	    // Method to perform linear search
	    public static int linearSearch(int[] arr, int target) {
	        for (int i = 0; i < arr.length; i++) {
	            if (arr[i] == target) {
	                return i; 
	            }
	        }
	        return -1;
	    }

	    public static void main(String[] args) {
	        int[] array = { 5, 10, 15, 20, 25, 30 };
	        int target = 15;

	        int index = linearSearch(array, target);

	        if (index != -1) {
	            System.out.println("Element found at index: " + index);
	        } else {
	            System.out.println("Element not found in the array.");
	        }
	    }
	}


