package com.learning.core.phaseC;

public class AssistedPractrice8 {

	    public static void quickSort(int[] arr, int low, int high) {
	        if (low < high) {
	            int partitionIndex = partition(arr, low, high);

	            quickSort(arr, low, partitionIndex - 1);
	            quickSort(arr, partitionIndex + 1, high);
	        }
	    }

	    public static int partition(int[] arr, int low, int high) {
	        int pivot = arr[high];
	        int i = low - 1;

	        for (int j = low; j < high; j++) {
	            if (arr[j] < pivot) {
	                i++;
	                swap(arr, i, j);
	            }
	        }

	        swap(arr, i + 1, high);
	        return i + 1;
	    }

	    public static void swap(int[] arr, int i, int j) {
	        int temp = arr[i];
	        arr[i] = arr[j];
	        arr[j] = temp;
	    }

	    public static void main(String[] args) {
	        int[] array = { 5, 3, 8, 1, 2, 7, 4 };
	        System.out.println("Array before sorting:");
	        printArray(array);

	        quickSort(array, 0, array.length - 1);

	        System.out.println("Array after sorting:");
	        printArray(array);
	    }

	    public static void printArray(int[] arr) {
	        for (int i = 0; i < arr.length; i++) {
	            System.out.print(arr[i] + " ");
	        }
	        System.out.println();
	    }
	}