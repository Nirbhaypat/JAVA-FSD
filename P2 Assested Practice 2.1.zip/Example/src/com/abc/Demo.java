package com.abc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/demo_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "9355";

    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    public static void createTable() {
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement()) {
            // Create 'employee' table if not exists
            String createTableQuery = "CREATE TABLE IF NOT EXISTS employee (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "Name VARCHAR(255) NOT NULL," +
                    "Email VARCHAR(255) NOT NULL" +
                    ")";
            statement.executeUpdate(createTableQuery);
            System.out.println("Table 'employee' created successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public static void insertData() {
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement()) {
            // Insert data into 'employee' table
            String insertDataQuery = "INSERT INTO employee (Name, Email) VALUES " +
                    "('John Doe', 'john.doe@example.com')," +
                    "('Jane Smith', 'jane.smith@example.com')";
            int rowsAffected = statement.executeUpdate(insertDataQuery);
            System.out.println(rowsAffected + " row(s) inserted into 'employee' table.");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        createTable(); // Create the 'employee' table
        insertData();  // Insert data into the 'employee' table
    }
}