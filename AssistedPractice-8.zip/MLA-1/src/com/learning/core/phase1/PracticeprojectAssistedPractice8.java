package com.learning.core.phase1;

public class PracticeprojectAssistedPractice8 {
	    private int outerValue = 10;

	    public class InnerClass {
	        public void display() {
	            System.out.println("InnerClass: OuterValue = " + outerValue);
	        }
	    }

	    public static void main(String[] args) {
	    	PracticeprojectAssistedPractice8 outerObj = new PracticeprojectAssistedPractice8();

	        InnerClass innerObj = outerObj.new InnerClass();

	        innerObj.display();
	    }
	}


