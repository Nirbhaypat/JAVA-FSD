package com.learning.core.phase1;

public class PracticeprojectAssistedPractice3 {

	  
	    public int add(int a, int b) {
	        return a + b;
	    }

	    
	    public int subtract(int a, int b) {
	        return a - b;
	    }

	    
	    public int multiply(int a, int b) {
	        return a * b;
	    }

	   
	    public double divide(int a, int b) {
	        if (b != 0) {
	            return (double) a / b;
	        } else {
	            System.out.println("Error: Division by zero.");
	            return Double.NaN;
	        }
	    }

	    public static void main(String[] args) {
	    	PracticeprojectAssistedPractice3 verifier = new PracticeprojectAssistedPractice3();

	       
	        int sum = verifier.add(5, 3);
	        int difference = verifier.subtract(10, 4);
	        int product = verifier.multiply(6, 7);
	        double quotient = verifier.divide(20, 4);

	        
	        System.out.println("Sum: " + sum);
	        System.out.println("Difference: " + difference);
	        System.out.println("Product: " + product);
	        System.out.println("Quotient: " + quotient);

	      
	        System.out.println("Sum: " + verifier.add(8, 2));
	        System.out.println("Difference: " + verifier.subtract(15, 7));
	        System.out.println("Product: " + verifier.multiply(9, 5));
	        System.out.println("Quotient: " + verifier.divide(25, 5));
	    }
	}


