package com.ExampleHibernet;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
    	  Configuration configuration = new Configuration().configure("hibernet.config.xml");
          SessionFactory sessionFactory = configuration.buildSessionFactory();

          // Create and save an employee with projects
          Session session = sessionFactory.openSession();
          Transaction transaction = session.beginTransaction();

          Employee employee = new Employee();
          employee.setName("John Doe");

          Project project1 = new Project();
          project1.setProjectName("Project A");
          project1.setEmployee(employee);

          Project project2 = new Project();
          project2.setProjectName("Project B");
          project2.setEmployee(employee);

          employee.getProjects().add(project1);
          employee.getProjects().add(project2);

          session.save(employee);

          transaction.commit();
          session.close();

          // Load the employee with lazy-loaded projects
          Session session2 = sessionFactory.openSession();
          Transaction transaction2 = session2.beginTransaction();

          Employee loadedEmployee = session2.get(Employee.class, employee.getId());
          // Projects collection is not loaded yet

          transaction2.commit();
          session2.close();

          // Now, access the lazy-loaded projects
          System.out.println("Employee: " + loadedEmployee.getName());
          // Projects collection will be loaded at this point
          System.out.println("Projects count: " + loadedEmployee.getProjects().size());

          sessionFactory.close();
      
    	        System.out.println("Record save successfully");
    	    }
    	}

    