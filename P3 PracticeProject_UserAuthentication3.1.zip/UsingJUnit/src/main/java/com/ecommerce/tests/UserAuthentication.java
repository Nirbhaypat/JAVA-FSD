package com.ecommerce.tests;

import java.util.HashMap;
import java.util.Map;

public class UserAuthentication {
    private Map<String, String> userDatabase;

    public UserAuthentication() {
        // Simulate a database with username-password pairs
        userDatabase = new HashMap<>();
        userDatabase.put("admin", "password");
        userDatabase.put("user1", "pass123");
        // Add more users as needed
    }

    public boolean authenticate(String username, String password) {
        // Check if username exists in the database
        if (userDatabase.containsKey(username)) {
            // Check if the password matches
            String storedPassword = userDatabase.get(username);
            return password.equals(storedPassword);
        }
        return false; // Username not found
    }
}
