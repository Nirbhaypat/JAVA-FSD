package com.Railway;

@Entity
public class Crossing {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String status;
    private String personInCharge;
    private String time;
    private String landmark;
    private String address;

    public Crossing() {
        // Default constructor
    }

    public Crossing(String name, String status, String personInCharge, String time, String landmark, String address) {
        this.name = name;
        this.status = status;
        this.personInCharge = personInCharge;
        this.time = time;
        this.landmark = landmark;
        this.address = address;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPersonInCharge() {
        return personInCharge;
    }

    public void setPersonInCharge(String personInCharge) {
        this.personInCharge = personInCharge;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Crossing{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", status='" + status + '\'' +
                ", personInCharge='" + personInCharge + '\'' +
                ", time='" + time + '\'' +
                ", landmark='" + landmark + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}