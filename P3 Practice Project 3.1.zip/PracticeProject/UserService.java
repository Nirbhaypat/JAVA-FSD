package com.service;

import com.entity.User;

public interface UserService {

    User getUserById(int userId);

    void updateUser(User user);
}
