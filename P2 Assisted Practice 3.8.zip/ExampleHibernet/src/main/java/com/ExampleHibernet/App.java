package com.ExampleHibernet;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        EmployeeDAO employeeDAO = context.getBean(EmployeeDAO.class);

        // Create and save an employee
        Employee employee = new Employee();
        employee.setFirstName("John");
        employee.setLastName("Doe");

        employeeDAO.saveEmployee(employee);

        // Retrieve and display the saved employee
        Employee retrievedEmployee = employeeDAO.getEmployeeById(employee.getId());
        System.out.println("Retrieved Employee: " + retrievedEmployee.getFirstName() + " " + retrievedEmployee.getLastName());
    }
}
