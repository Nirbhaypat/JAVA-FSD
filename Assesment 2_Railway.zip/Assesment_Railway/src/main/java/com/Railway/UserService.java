package com.Railway;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User registerUser(User user) {
        // Validation logic for registration
        if (user.getUsername() == null || user.getUsername().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty");
        }
        if (user.getPassword() == null || user.getPassword().isEmpty()) {
            throw new IllegalArgumentException("Password cannot be empty");
        }
        // You can add more validation logic as needed

        // Check if the username already exists
        if (userRepository.findByUsername(user.getUsername()) != null) {
            throw new IllegalArgumentException("Username already exists");
        }

        // Registration logic
        // For simplicity, assume the user is directly saved to the repository
        return userRepository.save(user);
    }

    public User loginUser(String username, String password) {
        // Validation logic for login
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            throw new IllegalArgumentException("Username and password are required");
        }

        // Login logic
        User user = userRepository.findByUsernameAndPassword(username, password);
        if (user == null) {
            throw new IllegalArgumentException("Invalid username or password");
        }
        return user;
    }
}

