package com.learning.core.phase1a;

import java.util.Scanner;

public class AssistedPractice4 {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        try {
	            
	            System.out.println("Enter an integer:");
	            int number = scanner.nextInt();
	            System.out.println("You entered: " + number);
	        } catch (Exception e) {
	            System.out.println("Error: Invalid input ");
	            scanner.close();
	        
	        }
	    }
	}
