package Com.Example;

import java.io.IOException;
import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/MyGenericServlet")
public class MyGenericServlet extends GenericServlet {

	@Override
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        // Set content type for the response
        response.setContentType("text/html");

        // Write HTML content to the response
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h1>Hello from Generic Servlet!</h1>");
        response.getWriter().println("</body></html>");
    }

}
